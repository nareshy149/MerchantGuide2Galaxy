package com.naresh.merchantguide;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
/*
* Merchant’s Guide To The Galaxy
* This class is mend to convert numbers and units.
* The numbers used for intergalactic transactions follows a similar
convention to the roman numerals and you have painstakingly collected the appropriate
translation between them. Roman numerals are based on seven symbols.
Symbols and values
I=1
V=5
X = 10
L = 250
C = 100
D = 500
M = 1000
 */

public class MerchantGuide2Galaxy {

    static Map<String, String> howMuchMoney = new HashMap<>();

    public static void main(String [] args) {
/*
 * Input lines taken as array to process further
 */
        String[] inputLines = {
                            "glob is Iprok is V",
                            "pish is X",
                            "tegj is L",
                            "glob glob Silver is 34 Credits",
                            "glob prok Gold is 57800 Credits",
                            "pish pish Iron is 3910 Credits",
                            "how much is pish tegj glob glob ?",
                            "how many Credits is glob prok Silver ?",
                            "how many Credits is glob prok Gold ?",
                            "how many Credits is glob prok Iron ?",
                            "how much wood could a woodchuck chuck if a woodchuck could chuck wood?"
                            };

        for (String line : inputLines) {
           parse(line);
        }
    }

    public static void parse(String line) {
        boolean validString = validate(line);

        if (validString) {
            if (line.contains("how many Credits")) {
                translate(line, "how many Credits is");
            } else if (line.contains("Silver")) {
                whichMetal(line, "Silver");
            } else if (line.contains("Gold")) {
                whichMetal(line, "Gold");
            } else if (line.contains("Iron")) {
                whichMetal(line, "Iron");
            } else if (line.contains("how much is")) {
                translate(line, "how much is ");
            } else if (!line.equals("") && line.contains("is")) {
                String delimiter = " is ";
                String[] output = line.split(Pattern.quote(delimiter));
                howMuchMoney.put(output[0], output[1]);
            } else{
                System.out.println("I have no idea what you are talking about");
            }
        }
        else {
            System.out.println("The string is invalid");
        }
    }

    public static boolean validate(String s) {
        return !s.contains("DD") && !s.contains("LL") && !s.contains("VV") && !s.contains("MMMM") && !s.contains("CCCC") && !s.contains("XXXX");
    }

    static void translate(String s, String separator) {
        double sum = 0;

        DecimalFormat df2  = new DecimalFormat("");

        // Splits the string based on whether we are asking how much or how many Credits
        String[] output = s.split(Pattern.quote(separator));

        // Intergalactic words (plus metal), ie glob prok Silver or tegj glob glob
        String individualWords = output[1];

        String[] outputWords = individualWords.split(" ");

        String romanNumeral ="";

        double value =0;

        for (String ow: outputWords) {
            if (!ow.equals("")) {
                if (!ow.equals("Silver") && (!ow.equals("Gold") && (!ow.equals("Iron")))) {

                    // Gets Roman numeral for the Galatic words ( sentence doesn't have Credits)
                    romanNumeral += howMuchMoney.get(ow);
                } else {
                    // Gets Roman numeral before the metal
                    value= Double.parseDouble(howMuchMoney.get(ow));

                    // Multiplies the number of units of the metal by the value of the metal
                    sum = value * romanToInt(romanNumeral);

                    // Remove the last space and ? and also show without decimals
                    System.out.println(output[1].trim().replaceAll(" \\?", "") +" is " + df2.format(sum).toString().replaceAll(",", "") + " Credits");
                }
            }
        }

        // Only prints out if it is not How many credits (since that has already been printed out)
        if (!output[1].contains("Silver") && !output[1].contains("Gold") && !output[1].contains("Iron")) {
            System.out.println(output[1].trim().replaceAll(" \\?", "") + " is " + romanToInt(romanNumeral));
        }
    }

    public static void whichMetal(String s, String metal) {

        String[] output = s.split(Pattern.quote(metal));

        // Galactic words before the type of metal
        String individualWords = output[0];
        String[] outputWords = individualWords.split(" ");

        StringBuilder romanNumeral = new StringBuilder();

        // Convert galactic words to Roman numerals
        for (String ow : outputWords) {
            romanNumeral.append(howMuchMoney.get(ow));
        }

        // Convert Roman numerals to regular numbers
        double convertedInt = romanToInt(romanNumeral.toString());

        String creditWords = output[1];

        // Splits the part of the String before Credit so that we get the number
        String[] creditOutputWords = creditWords.split(" ");

        int money = creditOutputWords.length - 2;

        double creditMoney = Double.parseDouble(creditOutputWords[money]);

        // Divides the number of credits by the value before the metal so we get the value for one unit of that metal
        double valueToInsert = 0;
        if (convertedInt !=0 ) {
            valueToInsert = creditMoney / convertedInt;
        } else {
            System.out.println("creditMoney " + creditMoney);
            System.out.println("convertedInt " + convertedInt);
        }
        // inserts the value of metal and the numeric value into the hashmap
        howMuchMoney.put(metal, Double.toString(valueToInsert));
    }

    public static int romanToInt(String s) {
        int[] nums = new int[s.length()];
        for (int i = 0; i < s.length(); i++) {
            switch (s.charAt(i)) {
                case 'M':
                    nums[i] = 1000;
                    break;
                case 'D':
                    nums[i] = 500;
                    break;
                case 'C':
                    nums[i] = 100;
                    break;
                case 'L':
                    nums[i] = 50;
                    break;
                case 'X':
                    nums[i] = 10;
                    break;
                case 'V':
                    nums[i] = 5;
                    break;
                case 'I':
                    nums[i] = 1;
                    break;
            }
        }
        int sum = 0;
        for (int i = 0; i < nums.length - 1; i++) {
            if (nums[i] < nums[i + 1])
                sum -= nums[i];
            else {
                sum += nums[i];
            }
        } return sum + nums[nums.length - 1];
    }
}
